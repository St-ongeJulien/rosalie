# Change log

###_Dérisquer l'application_ - 8 novembre 2022 :
Sections revues et corrigées:
- **Section 2.2** : Bases de données
