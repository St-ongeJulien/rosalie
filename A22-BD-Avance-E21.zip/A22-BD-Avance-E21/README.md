# README.md

## Les requêtes possibles de l’application:

### __README__

`@GET /readme`

returns:

    {
        "readme": README.md
    }

### __Choix de la ville__

`@GET /heartbeat`

returns:

    {
        "villeChoisie": str
    }

### __Extraction des données__

`@GET /extracted_data`

returns:

    {
        "nbRestaurants":int,
        "nbSegments":int (Segments cyclables)
    }

### __Transformation des données__

`@GET /transformed_data`

returns:

    {
        "restaurants":{ (Nombre de restaurants par type)
            $type1: int,
            $type2: int,
            ...
        },
        "longueurCyclable":float
    }

### __Obtenir la liste des types de restaurants disponibles__

`@GET /type`

returns:

    [
        str,
        str,
        str,
        ...
    ]

### __Obtenir un point de départ__

`@GET /starting_point`

payload:

    {
        "length": int (en mètre),
        "type": [str, str, ... ]
    }

returns:

    {
        "startingPoint" : {"type":"Point", "coordinates":[float, float]}
    }

### __Obtenir un parcours de vélo épicurien__

`@GET /parcours`

payload:

    {
        "startingPoint" : {
            "type":"Point",
            "coordinates":[
                float, float
            ]
        },
        "length": int (en mètre),
        "numberOfStops": int,
        "type": [
            str,
            str,
            ...
        ]
    }

returns:

    {
        "type": "FeatureCollection",
        "features": 
        [ (liste des elements constituants le parcours)
            { (Exemple de restaurant)
                "type":"Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates":  [float, float]
                },
                "properties":{
                    "name":str,
                    "type":str
                }
            },
            ...,
            { (Exemple de segment de piste cyclabe)
                "type":"Feature",
                "geometry": {
                    "type": "MultiLineString",
                    "coordinates": [
                    [
                        [
                            float, float
                        ],
                        [
                            float, float
                        ],
                        [
                            float, float
                        ],
                    ...
                    ]
                    ]
                },
                "properties": {
                    "length": float (en mètres)
                }
            }
        ]
    }
### Commandes importantes

- `docker compose up -d` Start la stack de notre webapp contenue dans le docker compose
- `docker compose stop` Arrête tous les container du docker compose

### Liens
- https://hub.docker.com/
