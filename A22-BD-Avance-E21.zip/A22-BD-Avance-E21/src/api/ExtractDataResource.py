from flask_restful import Resource

from src.domain import DomainService


class ExtractDataResource(Resource):
    def __init__(self, service: DomainService) -> None:
        self.service = service

    def get(self):
        return self.service.get_extracted_data()
