from flask_restful import Resource
from flask import request

from src.domain import DomainService


class ParcoursResource(Resource):
    def __init__(self, service: DomainService) -> None:
        self.service = service

    def get(self):
        payload = request.get_json()
        error = "The payload is not on a valid format"
        try:
            if type(payload["length"]) is not int:
                error = "length is not an int"
                raise Exception()
            if type(payload["numberOfStops"]) is not int:
                error = "numberOfStops is not an int"
                raise Exception()
            if type(payload["type"]) is not list:
                error = "type is not a list"
                raise Exception()
            if type(payload["startingPoint"]) is not dict:
                error = "startingPoint is not a valid format"
                raise Exception()
        except:
            return {"ERROR": error}, 400
        try:
            response = self.service.get_feature_collection(payload), 200
        except:
            response = {
                "ERROR": "There's no cycling lane in range of the requested length"
            }, 400
        return response
