from flask_restful import Resource


class ReadmeResource(Resource):
    def get(self):
        with open("./README.md", "r") as readme:
            return readme.read()
