from flask_restful import Resource

from src.domain import DomainService


class HeartbeatResource(Resource):
    def __init__(self, service: DomainService) -> None:
        self.service = service

    def get(self):
        if self.service.heartbeat():
            return {"villeChoisie": "Philadelphie"}, 200
        else:
            return {"STATUS": "App still initializing"}, 500
