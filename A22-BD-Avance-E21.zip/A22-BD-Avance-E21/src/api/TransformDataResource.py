from flask_restful import Resource

from src.domain import DomainService


class TransformDataResource(Resource):
    def __init__(self, service: DomainService) -> None:
        self.service = service

    def get(self):
        return self.service.get_transformed_data()
