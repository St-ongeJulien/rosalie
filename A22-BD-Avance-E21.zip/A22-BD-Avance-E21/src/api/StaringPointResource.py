from flask_restful import Resource
from flask import request

from src.domain import DomainService


class StartingPointResource(Resource):
    def __init__(self, service: DomainService) -> None:
        self.service = service

    def get(self):
        payload = request.get_json()
        error = "The payload is not on a valid format"
        try:
            if type(payload["length"]) is not int:
                error = "The length is not an int"
                raise Exception()
            if type(payload["type"]) is not list:
                error = "The type field is not a list"
                raise Exception()
        except:
            return {"ERROR": error}, 400
        try:
            response = self.service.get_starting_point(payload["type"]), 200
        except:
            response = {"ERROR": "Some restaurant types doesn't exist"}, 400
        return response
