from time import sleep

from py2neo import Graph
from geopy import distance
from src.domain.entities import CycleLane


class Neo4JRepository:
    def __init__(self):
        self.graph = self._initialise()
        print("Connected: Neo4J")
        self.delete_all()

    def _initialise(self):
        while True:
            sleep(1)
            try:
                return Graph(host="neo4j_flask", port="7687")
                # return Graph(host="localhost", port="7687")
            except Exception:
                print("Trying to connect Neo4J....")
                pass

    def save(self, cycle_lane: CycleLane):
        pass

    def save_many(self, restaurants, cycle_lanes):
        for restaurant in restaurants:
            self.graph.run(
                f"CREATE (:Restaurant{{name:\"{restaurant['name']}\", restaurant_id:\"{restaurant['restaurant_id']}\", "
                f"longitude:{restaurant['location']['coordinates'][0]}, "
                f"latitude:{restaurant['location']['coordinates'][1]}, "
                f"types:\"{restaurant['types']}\"}}) "
            )

        for cycle_lane in cycle_lanes:
            cycle_lane_coordinates = cycle_lane["coordinates"]["coordinates"]
            total_coordinates = len(cycle_lane_coordinates)
            last_coordinate = None
            last_coordinate_id = None
            i = 0

            for cycle_lane_coordinate in cycle_lane_coordinates:
                if last_coordinate_id is None:
                    cycle_lane_id = self.graph.run(
                        f"CREATE (cycleLane:CycleLane{{longitude:{cycle_lane_coordinate[0]}, latitude:{cycle_lane_coordinate[1]}}}) "
                        f"RETURN ID(cycleLane)"
                    ).data()[0]["ID(cycleLane)"]

                    last_coordinate_id = cycle_lane_id
                    last_coordinate = cycle_lane_coordinate

                elif last_coordinate_id is not None:

                    try:
                        distance_to_next_coordinate = distance.distance(
                            cycle_lane_coordinate, last_coordinate
                        ).m
                        if (
                            i == distance_to_next_coordinate > 25
                            or i == total_coordinates - 1
                        ):
                            cycle_lane_id = self.graph.run(
                                f"CREATE (cycleLane:CycleLane{{longitude:{cycle_lane_coordinate[0]}, "
                                f"latitude:{cycle_lane_coordinate[1]}}}) "
                                f"RETURN ID(cycleLane)"
                            ).data()[0]["ID(cycleLane)"]

                            self.graph.run(
                                f"""MATCH (currentCycleLane:CycleLane),(previousCycleLane:CycleLane)
                                    WHERE ID(currentCycleLane) = {cycle_lane_id} AND ID(previousCycleLane) = {last_coordinate_id}
                                    CREATE (currentCycleLane)-[:adjacent{{distance_to_next_coordinate:{distance_to_next_coordinate}}}]->(previousCycleLane)
                                    CREATE (previousCycleLane)-[:adjacent{{distance_to_next_coordinate:{distance_to_next_coordinate}}}]->(currentCycleLane)
                                    """
                            )

                            last_coordinate_id = cycle_lane_id
                            last_coordinate = cycle_lane_coordinate

                    except:
                        raise Exception("exception")

                i += 1

        # Match Restaurant and CycleLanes
        for restaurant in self.graph.run(
            "MATCH (restaurant:Restaurant) RETURN restaurant, "
            "ID(restaurant) as restaurant_id"
        ):

            restaurant_id = restaurant["restaurant_id"]

            restaurant_coordinate = (
                restaurant["restaurant"]["longitude"],
                restaurant["restaurant"]["latitude"],
            )

            cycle_lane_length = float("inf")
            min_cycle_lane_length_id = None

            cycle_lane_relation = 0

            for lane in self.graph.run(
                "MATCH (cycleLane:CycleLane) RETURN cycleLane, ID(cycleLane) as cycleLane_id"
            ):
                cycle_lane_id = lane["cycleLane_id"]

                cycle_lane_coordinate = (
                    lane["cycleLane"]["longitude"],
                    lane["cycleLane"]["latitude"],
                )

                distance_to_next_coordinate = distance.distance(
                    cycle_lane_coordinate, restaurant_coordinate
                ).m

                if distance_to_next_coordinate < cycle_lane_length:
                    min_cycle_lane_length_id = cycle_lane_id
                    cycle_lane_length = distance_to_next_coordinate

                if distance_to_next_coordinate < 600:
                    self.graph.run(
                        f"""MATCH (restaurant:Restaurant), (cycleLane:CycleLane)
                            WHERE ID(restaurant) = {restaurant_id} AND ID(cycleLane) = {cycle_lane_id}
                            CREATE (restaurant)-[:adjacent{{distance_to_next_coordinate:{distance_to_next_coordinate}}}]->(cycleLane)
                            CREATE (cycleLane)-[:adjacent{{distance_to_next_coordinate:{distance_to_next_coordinate}}}]->(restaurant)
                            """
                    )
                    cycle_lane_relation += 1

            if not cycle_lane_relation:
                self.graph.run(
                    f"""MATCH (restaurant:Restaurant), (cycleLane:CycleLane)
                                    WHERE ID(restaurant) = {restaurant_id} AND ID(cycleLane) = {min_cycle_lane_length_id}
                                    CREATE (restaurant)-[:adjacent{{distance_to_next_coordinate:{cycle_lane_length}}}]->(cycleLane)
                                    CREATE (cycleLane)-[:adjacent{{distance_to_next_coordinate:{cycle_lane_length}}}]->(restaurant)
                                    """
                )

    def find_by_id(self, id: str):
        pass

    def find_all(self):
        pass

    def find_total_segments(self) -> int:
        return self.graph.run("MATCH (lane:CycleLane) RETURN count(*)").data()[0][
            "count(*)"
        ]

    def find_sum_segments_distance(self) -> float:
        return self.graph.run(
            "MATCH (lane:CycleLane) RETURN SUM(lane.segment_length)"
        ).data()[0]["SUM(lane.segment_length)"]

    def delete_all(self):
        try:
            self.graph.run("MATCH (cycleLane:CycleLane) DETACH DELETE cycleLane;")
            self.graph.run("MATCH (restaurant:Restaurant) DETACH DELETE restaurant;")
        except Exception as e:
            print("ixdé")
