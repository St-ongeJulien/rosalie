from pymongo import MongoClient

from src.domain.entities import Restaurant, CycleLane


class MongoDBRepository:
    def __init__(self):
        self.client = MongoClient("mongodb://mongodb_flask:27017")
        # self.client = MongoClient("mongodb://localhost:27017")
        print("Connected: MongoDB")
        db = self.client["restaurant_db"]
        try:
            db.drop_collection("restaurants")
            db.drop_collection("cycle_lanes")
            print("Clean Outdated MongoDB Dataset")
        except:
            print("")
        self.restaurants_collection = db["restaurants"]
        self.cycles_lanes_collection = db["cycle_lanes"]

    def save(self, restaurant: Restaurant):
        pass

    def save_many(
        self, restaurants: list[Restaurant], cycle_lanes: list[CycleLane]
    ) -> None:
        data_restaurants = []
        for restaurant in restaurants:
            data_restaurants.append(
                {
                    "restaurant_id": restaurant.id,
                    "name": restaurant.name,
                    "types": restaurant.types,
                    "location": {
                        "type": "Point",
                        "coordinates": [
                            restaurant.coordinate.longitude,
                            restaurant.coordinate.latitude,
                        ],
                    },
                }
            )
        self.restaurants_collection.insert_many(data_restaurants)
        self.restaurants_collection.create_index([("location", "2dsphere")])
        print("Saved latest MongoDB restaurants")

        data_cycle_lanes = []
        for cycle_lane in cycle_lanes:
            coordinates = []
            for x in cycle_lane.coordinates:
                coordinates.append([x.longitude, x.latitude])
            data_cycle_lanes.append(
                {
                    "cycle_lane_id": cycle_lane.id,
                    "street_name": cycle_lane.street_name,
                    "segment_length": cycle_lane.segment_length,
                    "coordinates": {"type": "LineString", "coordinates": coordinates},
                }
            )
        self.cycles_lanes_collection.insert_many(data_cycle_lanes)
        self.restaurants_collection.create_index([("coordinates", "2dsphere")])
        print("Saved latest MongoDB cycles lanes")

    def find_by_id(self, id: str):
        pass

    def find_all_by_type(self) -> dict[str, int]:
        data = {}
        query = [
            {"$unwind": "$types"},
            {"$group": {"_id": "$types", "tags": {"$sum": 1}}},
            {"$project": {"_id": 0, "type": "$_id", "tags": 1}},
            {"$sort": {"tags": -1}},
        ]
        items = self.restaurants_collection.aggregate(query)
        for row in items:
            data[row["type"]] = row["tags"]
        return data

    def get_total_restaurant(self) -> int:
        return self.restaurants_collection.count()

    def find_all_restaurants(self):
        return self.restaurants_collection.find({})

    def find_all_cycle_lanes(self):
        return self.cycles_lanes_collection.find({})

    def find_restaurant_by_types(self, types):
        if types == []:
            return list(self.restaurants_collection.find({}))
        else:
            return list(self.restaurants_collection.find({"types": {"$in": types}}))

    def get_same_size_cycle_lane(self, length):
        min = length * 0.9
        max = length * 1.1
        return list(
            self.cycles_lanes_collection.find(
                {"segment_length": {"$gte": min, "$lte": max}}
            )
        )
