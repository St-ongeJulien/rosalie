import requests

from src.domain.entities import Coordinate, Restaurant
from src.domain.sources import PhillyRestaurantsSource


class YelpSource(PhillyRestaurantsSource):
    def get_restaurants(self):
        data = []

        token = "x1AGbEHMq1aCX2vissQJdj7rn00efwwsdsXl_nC6MPKpdhBpLBbnRGw5jn-ZdOgQrPNQOT_95_OryRE0TQgZS6KiBzWKgoQk-VOJErgS_3RfEIxLm9dakD3HkY1pY3Yx"
        headers = {"Authorization": "Bearer " + token}
        url = "https://api.yelp.com/v3/businesses/search"

        items = []
        # for diff in range(0, 5000, 50):
        for diff in range(0, 250, 50):
            params = {
                "limit": 50,
                "location": "Philadelphia",
                "term": "restaurants",
                "offset": diff,
            }
            response = requests.get(url, headers=headers, params=params)
            if response.status_code == 200:
                items += response.json()["businesses"]
            elif response.status_code >= 400:
                break

        for row in items:
            id = row["id"]
            name = row["name"]
            types = []
            for type in row["categories"]:
                types.append(type["alias"])
            coordinate = Coordinate(
                row["coordinates"]["latitude"], row["coordinates"]["longitude"]
            )

            data.append(Restaurant(id, name, types, coordinate))
        print("Fetch: Restaurant")
        return data
