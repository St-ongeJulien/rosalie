import requests

from src.domain.entities import CycleLane, Coordinate
from src.domain.sources import PhillyCycleLaneSource


class OpenDataPhillySource(PhillyCycleLaneSource):
    def get_cycle_lanes(self) -> list[CycleLane]:
        data = []
        response = requests.get(
            "https://opendata.arcgis.com/datasets/b5f660b9f0f44ced915995b6d49f6385_0.geojson"
        )
        items = response.json()["features"]
        for i in range(50):
            row = items[i]
            id = row["properties"]["SEG_ID"]
            street_name = row["properties"]["STREETNAME"]
            segment_length = row["properties"]["Shape__Length"]

            coordinates = []
            for coordinate in row["geometry"]["coordinates"]:
                coordinates.append(Coordinate(coordinate[1], coordinate[0]))

            data.append(CycleLane(id, street_name, segment_length, coordinates))
        print("Fetch: Cycles lanes")
        return data
