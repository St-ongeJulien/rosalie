from abc import ABC, abstractmethod


class PhillyRestaurantsSource(ABC):
    @classmethod
    def __subclasshook__(cls, subclass):
        if cls is PhillyRestaurantsSource:
            return True
        return NotImplemented

    @abstractmethod
    def get_restaurants(self):
        pass
