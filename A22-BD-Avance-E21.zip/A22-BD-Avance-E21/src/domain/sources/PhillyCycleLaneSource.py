from abc import ABC, abstractmethod


class PhillyCycleLaneSource(ABC):
    @classmethod
    def __subclasshook__(cls, subclass):
        if cls is PhillyCycleLaneSource:
            return True
        return NotImplemented

    @abstractmethod
    def get_cycle_lanes(self):
        pass
