from src.domain.entities import Coordinate, Restaurant, CycleLane
from src.domain.sources import PhillyCycleLaneSource, PhillyRestaurantsSource
from src.infrastructure.repositories import Neo4JRepository, MongoDBRepository
import random


class DomainService:
    def __init__(
        self,
        neo4j_repository: Neo4JRepository,
        mongodb_repository: MongoDBRepository,
        philly_cycle_lane_source: PhillyCycleLaneSource,
        philly_restaurant_source: PhillyRestaurantsSource,
    ) -> None:
        self.neo4j_repository = neo4j_repository
        self.mongodb_repository = mongodb_repository
        self.philly_cycle_lane_source = philly_cycle_lane_source
        self.philly_restaurant_source = philly_restaurant_source
        self.isReady = False
        self.initialize_latest_data_sets()

    def initialize_latest_data_sets(self):
        # self._load_initial_cycle_lanes()
        self._load_mongodb()
        self._load_neo4j()
        print("App is data is ready to interact with")
        self.isReady = True

    def _load_neo4j(self):
        restaurants_cursor = self.mongodb_repository.find_all_restaurants()
        cycle_lanes_cursor = self.mongodb_repository.find_all_cycle_lanes()
        self.neo4j_repository.save_many(restaurants_cursor, cycle_lanes_cursor)

    def _load_mongodb(self):
        cycle_lanes = self.philly_cycle_lane_source.get_cycle_lanes()
        restaurants = self.philly_restaurant_source.get_restaurants()
        self.mongodb_repository.save_many(restaurants, cycle_lanes)

    def heartbeat(self) -> bool:
        return self.isReady

    def get_extracted_data(self):
        restaurant_count = self.mongodb_repository.get_total_restaurant()
        segment_count = self.neo4j_repository.find_total_segments()
        return {"nbRestaurants": restaurant_count, "nbSegments": segment_count}

    def get_transformed_data(self):
        types = self.mongodb_repository.find_all_by_type()
        sum_segment_distance = self.neo4j_repository.find_sum_segments_distance()
        return {"restaurants": types, "longueurCyclable": sum_segment_distance}

    def get_feature_collection(self, payload):
        types = payload["type"]
        spots = int(payload["numberOfStops"])
        length = payload["length"]
        restaurants_raw = self.mongodb_repository.find_restaurant_by_types(types)
        restaurants = []
        for resto in restaurants_raw:
            restaurants.append(
                self._generate_restaurant_collection(
                    resto["location"]["coordinates"][0],
                    resto["location"]["coordinates"][1],
                    resto["name"],
                    resto["types"],
                )
            )

        cycle_lane_raw = random.choice(
            self.mongodb_repository.get_same_size_cycle_lane(length)
        )
        cycle_lane = self._generate_cycle_lane_collection(
            cycle_lane_raw["coordinates"]["coordinates"],
            cycle_lane_raw["segment_length"],
        )

        return {
            "type": "FeatureCollection",
            "features": [restaurants[0:spots], cycle_lane],
        }

    def _generate_restaurant_collection(self, longitude, latitude, name, types):
        return {
            "type": "Feature",
            "geometry": {
                "type": "Point",
                "coordinates": [
                    longitude,
                    latitude,
                ],
            },
            "properties": {"name": name, "type": types},
        }

    def _generate_cycle_lane_collection(self, coordinates, length):
        return {
            "type": "Feature",
            "geometry": {"type": "MultiLineString", "coordinates": coordinates},
            "properties": {"length": length},
        }

    def get_restaurant_type(self):
        return list(self.mongodb_repository.find_all_by_type().keys())

    def get_starting_point(self, types):
        restaurantByType = self.mongodb_repository.find_restaurant_by_types(types)
        restaurant = random.choice(restaurantByType)
        return {"startingPoint": restaurant["location"]}
