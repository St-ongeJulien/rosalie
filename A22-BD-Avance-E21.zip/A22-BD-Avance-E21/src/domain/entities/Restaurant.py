from src.domain.entities import Coordinate


class Restaurant:
    def __init__(
        self, id: str, name: str, types: list[str], coordinate: Coordinate
    ) -> None:
        self.id = id
        self.name = name
        self.types = types
        self.coordinate = coordinate
