class Coordinate:
    def __init__(self, latitude: float, longitude: float) -> None:
        self.latitude = latitude
        self.longitude = longitude

    def __eq__(self, other):
        return (self.latitude, self.longitude) == (other.latitude, other.longitude)
