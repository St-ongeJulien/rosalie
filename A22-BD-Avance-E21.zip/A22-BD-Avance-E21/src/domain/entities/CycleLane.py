from src.domain.entities import Coordinate


class CycleLane:
    def __init__(
        self,
        id: str,
        street_name: str,
        segment_length: float,
        coordinates: list[Coordinate],
    ) -> None:
        self.id = id
        self.street_name = street_name
        self.segment_length = segment_length
        self.coordinates = coordinates
