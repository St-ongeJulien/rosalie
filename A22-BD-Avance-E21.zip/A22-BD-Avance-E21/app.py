from flask import Flask
from flask_restful import Api

from src.api import (
    HeartbeatResource,
    ExtractDataResource,
    TransformDataResource,
    ReadmeResource,
    TypeResource,
    StartingPointResource,
    ParcoursResource,
)
from src.domain import DomainService
from src.infrastructure.repositories import (
    Neo4JRepository,
    MongoDBRepository,
)
from src.infrastructure.sources import OpenDataPhillySource, YelpSource

app = Flask(__name__)
api = Api(app)

neo4j = Neo4JRepository()
mongodb = MongoDBRepository()
cycle_lanes_source = OpenDataPhillySource()
restaurants_source = YelpSource()

domain_service = DomainService(neo4j, mongodb, cycle_lanes_source, restaurants_source)

api.add_resource(HeartbeatResource, "/heartbeat", resource_class_args=[domain_service])
api.add_resource(
    ExtractDataResource, "/extracted_data", resource_class_args=[domain_service]
)
api.add_resource(
    TransformDataResource, "/transformed_data", resource_class_args=[domain_service]
)
api.add_resource(ReadmeResource, "/readme")
api.add_resource(TypeResource, "/type", resource_class_args=[domain_service])
api.add_resource(
    StartingPointResource, "/starting_point", resource_class_args=[domain_service]
)
api.add_resource(ParcoursResource, "/parcours", resource_class_args=[domain_service])

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
